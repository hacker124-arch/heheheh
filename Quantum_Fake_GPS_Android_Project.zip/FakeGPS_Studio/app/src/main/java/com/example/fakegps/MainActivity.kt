package com.example.fakegps

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {

    private var selectedLat = 34.0151
    private var selectedLng = 71.5249
    private var isSpoofing = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        requestPermissions()

        val webView = findViewById<WebView>(R.id.webView)
        val btnToggle = findViewById<Button>(R.id.btnToggle)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/map.html")

        btnToggle.setOnClickListener {
            if (!isSpoofing) {
                startSpoofing(btnToggle)
            } else {
                stopSpoofing(btnToggle)
            }
        }
    }

    private fun startSpoofing(button: Button) {
        val intent = Intent(this, MockLocationService::class.java).apply {
            putExtra("LAT", selectedLat)
            putExtra("LNG", selectedLng)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            isSpoofing = true
            button.text = "STOP FAKE LOCATION"
            button.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF581C87.toInt())
            Toast.makeText(this, "Fake Location Started!", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Select this app in Developer Options -> Mock Location App", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        }
    }

    private fun stopSpoofing(button: Button) {
        stopService(Intent(this, MockLocationService::class.java))
        isSpoofing = false
        button.text = "START FAKE LOCATION"
        button.backgroundTintList = android.content.res.ColorStateList.valueOf(0xFF7E22CE.toInt())
        Toast.makeText(this, "Fake Location Stopped", Toast.LENGTH_SHORT).show()
    }

    private fun requestPermissions() {
        val perms = mutableListOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (perms.any { ActivityCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(this, perms.toTypedArray(), 1)
        }
    }

    inner class WebAppInterface {
        @JavascriptInterface
        fun onLocationSelected(lat: Double, lng: Double) {
            selectedLat = lat
            selectedLng = lng
        }
    }
}
