package com.example.fakegps

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.location.LocationManager
import android.location.provider.ProviderProperties
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.NotificationCompat

class MockLocationService : Service() {

    private lateinit var locationManager: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private var lat = 0.0
    private var lng = 0.0
    private var isRunning = false

    private val updateRunnable = object : Runnable {
        override fun run() {
            if (!isRunning) return
            pushMockLocation(LocationManager.GPS_PROVIDER, lat, lng)
            pushMockLocation(LocationManager.NETWORK_PROVIDER, lat, lng)
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        lat = intent?.getDoubleExtra("LAT", 0.0) ?: 0.0
        lng = intent?.getDoubleExtra("LNG", 0.0) ?: 0.0

        val notification = NotificationCompat.Builder(this, "MOCK_GPS_CHANNEL")
            .setContentTitle("Fake Location Active")
            .setContentText("Spoofing: ${String.format("%.4f", lat)}, ${String.format("%.4f", lng)}")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .build()

        startForeground(101, notification)

        setupTestProvider(LocationManager.GPS_PROVIDER)
        setupTestProvider(LocationManager.NETWORK_PROVIDER)

        isRunning = true
        handler.post(updateRunnable)

        return START_STICKY
    }

    private fun setupTestProvider(provider: String) {
        try {
            locationManager.removeTestProvider(provider)
        } catch (_: Exception) {}

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                locationManager.addTestProvider(
                    provider, false, false, false, false,
                    true, true, true,
                    ProviderProperties.POWER_USAGE_LOW,
                    ProviderProperties.ACCURACY_FINE
                )
            } else {
                @Suppress("DEPRECATION")
                locationManager.addTestProvider(
                    provider, false, false, false, false,
                    true, true, true, 1, 1
                )
            }
            locationManager.setTestProviderEnabled(provider, true)
        } catch (e: SecurityException) {
            stopSelf()
        }
    }

    private fun pushMockLocation(provider: String, latitude: Double, longitude: Double) {
        try {
            val mockLocation = Location(provider).apply {
                this.latitude = latitude
                this.longitude = longitude
                this.altitude = 10.0
                this.time = System.currentTimeMillis()
                this.accuracy = 3.0f
                this.elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
            }
            locationManager.setTestProviderLocation(provider, mockLocation)
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        isRunning = false
        handler.removeCallbacks(updateRunnable)
        try {
            locationManager.removeTestProvider(LocationManager.GPS_PROVIDER)
            locationManager.removeTestProvider(LocationManager.NETWORK_PROVIDER)
        } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "MOCK_GPS_CHANNEL",
                "Mock Location Service",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
}
